# ZadLoop Same-Session Undo — 1.1.0

An **Undo button for ZadLoop desktop 0.4.0**. For each exchange, an **"Undo this exchange"** button removes **your message and the model's reply after it** from the model's context **and from the transcript** — inside the **same session**. No fork, no new session, no history deletion.

## What changed from 1.0.0

- The marker is now a `user/message` replacement (the same idle-safe event family compaction uses) instead of a `developer/message` — that was the cause of the `developer/message turn must be a non-negative safe integer` error. **Update: uninstall/disable 1.0.0, install 1.1.0, restart ZadLoop.**
- The button moved from the assistant strip to each **turn tail** (the row under every exchange, where the branch action lives) and undoes exactly that exchange — including middle exchanges, not only the latest.
- The transcript now **hides** the undone exchange: the plugin reads its durable markers and hides the affected chat nodes and turn tails. If a node's internal key format ever changes, worst case an undone exchange stays visible while still being out of context.
- The model sees one tiny `[undone by user]` marker where the exchange used to be.

## What Undo does

- Appends one supported *surface replacement* event that shadows your message and the reply after it from the model's history; the log stays append-only (audit trail preserved), and the session id never changes.
- Works per exchange — undo a middle exchange and later ones stay.
- Repeated undo walks back through exchanges.
- The next model request starts a fresh request series automatically.

## What Undo deliberately does NOT do

- **It does not delete history.** Undone messages stay in the durable log (hidden from the transcript, excluded from context).
- **It does not revert side effects** — files, commands, deployments stay executed.
- **It cannot undo into a compacted region** (after `/compact`).
- **It refuses while the agent is working.** Stop the turn first.

## Install once

1. **Settings → General → Developer mode** on.
2. Remove/disable version 1.0.0 if you installed it (Plugins → dsh-zadloop-undo → off/uninstall).
3. **Plugins → Add plugin**, paste:

   ```text
   C:\Users\Lucifer\Desktop\zadloop-undo
   ```

   (or the archive `C:\Users\Lucifer\Desktop\zadloop-undo\dsh-zadloop-undo-1.1.0.tgz` — one, not both)
4. Install, enable `dsh-zadloop-undo`, restart ZadLoop once if asked.

## Use

Under each exchange (next to the branch action) an **Undo this exchange** button appears. Click it: your message and the reply vanish from the transcript and from the model's context; type the corrected message and send. Status text reports `Undone`, `Agent is running — stop it first`, `Nothing to undo here`, or `Open this session first`.

## Safety

- Runs under the agent's **atomic maintenance gate**; per-session requests are serialized; refusals never modify the log.
- The marker passes the session format's own codec: a full write + re-read round-trip through the installed persistence codec is part of the test suite.
- Remote-control interplay: anyone reaching your public remote-control URL can also undo — consistent with that plugin's no-login design.

## Tests

```powershell
node --test test/*.test.js
```

**12 tests passed with no skips on this PC** against the installed ZadLoop runtime, including: latest/middle/repeated undo over the real session fold, compaction refusal, head protection, busy/not-live/empty gates leaving the log untouched, route validation, marker **durability through the real JSONL codec (write, re-read, re-fold)**, and both routes end-to-end through the real Connection bridge. Live installation was not performed during packaging.
