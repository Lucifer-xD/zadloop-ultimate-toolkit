/**
 * dsh-zadloop-undo — same-session Undo for ZadLoop desktop 0.4.0.
 *
 * Undo appends ONE `user/message` replacement — the same event shape compaction
 * uses for its checkpoint, which is the only surface replacement the session
 * format admits while no turn is open. The marker carries a distinct
 * `zadloop-undo` source kind (never `compact-checkpoint`, which would demand a
 * compaction owner), a tiny `[undone by user]` text the model sees, and
 * `sourceEventSeqs` covering every shadowed surface node. The fold removes
 * your message and everything after it (or up to one exchange's end) from the
 * model's context; the log stays append-only and the session id never changes.
 *
 * The shipped transcript intentionally renders append-origin events only, so
 * the browser half additionally hides the shadowed conversation through CSS
 * derived from the marker events themselves.
 *
 * This package deliberately imports nothing from @deepseek-ai/* at runtime:
 * a folder-link install cannot resolve the runtime's packages, and everything
 * needed (surface nodes, append validation, flush) is reachable through the
 * live Session object and injected services.
 */
import { randomUUID } from 'node:crypto';

/** Stable Cordis plugin name. */
export const name = 'zadloop-undo';
/** Required Host services: the /api route owner, the Session store, the Agent registry. */
export const inject = ['connection', 'sessions', 'agents'];

const UNDO_PATH = '/api/zadloop-undo/undo';
const STATE_PATH = '/api/zadloop-undo/state';
const MAX_PREVIEW_CHARS = 80;
/** Source kind identifying undo markers in the durable log. */
export const MARKER_KIND = 'zadloop-undo';
/** The one short line the model reads where an undone exchange used to be. */
export const MARKER_TEXT = '[undone by user]';

function isEventSeq(value) {
	return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0;
}

function previewOf(userEvent) {
	const blocks = userEvent?.data?.content;
	if (!Array.isArray(blocks)) return undefined;
	for (const block of blocks) {
		if (block?.type === 'text' && typeof block.text === 'string' && block.text.trim() !== '') {
			const text = block.text.trim();
			return text.length > MAX_PREVIEW_CHARS ? `${text.slice(0, MAX_PREVIEW_CHARS)}…` : text;
		}
	}
	return blocks.length > 0 ? '(attachment)' : undefined;
}

/**
 * Plan one undo over the current surface.
 *
 * Targets the last append-origin `user/message` whose source is the person
 * themself (kind `'user'`). Without `throughSeq` the range ends at the surface
 * tail (the latest exchange); with it, the range ends at the last current
 * surface node at or before that seq, so a single middle exchange can be
 * undone while later ones stay visible. Compaction checkpoints, undo markers,
 * and other injected sources are skipped by the backward scan, and a match at
 * surface index 0 is refused so the system-prompt head is never covered.
 *
 * @param events - frozen session events (the live snapshot).
 * @param surfaceNodes - current surface seqs in model-visible order (`session.surface.nodes`).
 * @param throughSeq - optional inclusive end anchor (a turn-tail seq).
 * @returns the replacement plan, or `{ ok: false, code }`.
 */
export function planUndo(events, surfaceNodes, throughSeq) {
	if (!Array.isArray(events) || !Array.isArray(surfaceNodes) || surfaceNodes.length === 0) {
		return { ok: false, code: 'nothing-to-undo' };
	}
	if (throughSeq !== undefined && !isEventSeq(throughSeq)) {
		return { ok: false, code: 'bad-anchor' };
	}
	let endIndex = surfaceNodes.length - 1;
	if (throughSeq !== undefined) {
		while (endIndex >= 0 && surfaceNodes[endIndex] > throughSeq) endIndex -= 1;
	}
	if (endIndex < 1) return { ok: false, code: 'nothing-to-undo' };
	const bySeq = new Map(events.map((event) => [event.seq, event]));
	for (let index = endIndex; index >= 1; index--) {
		const seq = surfaceNodes[index];
		if (!isEventSeq(seq)) return { ok: false, code: 'invalid-surface' };
		const event = bySeq.get(seq);
		if (event === undefined) return { ok: false, code: 'invalid-surface' };
		if (event.type !== 'user/message' || event.surfaceOp !== 'append') continue;
		if (event.data?.source?.kind !== 'user') continue;
		return {
			ok: true,
			startSeq: seq,
			endSeq: surfaceNodes[endIndex],
			shadowedSeqs: surfaceNodes.slice(index, endIndex + 1),
			removedMessages: endIndex - index + 1,
			preview: previewOf(event),
		};
	}
	return { ok: false, code: 'nothing-to-undo' };
}

/**
 * Append the undo marker to a live Session. Structural validation (current
 * endpoints, complete shadowed coverage, earlier references) happens inside
 * `session.append`, which rejects before the log changes.
 * @param session - live Session instance.
 * @param plan - a successful {@link planUndo} result.
 * @returns the committed marker event.
 */
export function applyUndoMarker(session, plan) {
	return session.append(
		'user/message',
		{
			role: 'user',
			id: `zadloop-undo-${randomUUID()}`,
			content: [{ type: 'text', text: MARKER_TEXT }],
			source: { kind: MARKER_KIND },
		},
		{
			surfaceOp: { op: 'replace', startSeq: plan.startSeq, endSeq: plan.endSeq },
			sourceEventSeqs: [...plan.shadowedSeqs],
		},
	);
}

/**
 * Undo one exchange of a session under the Agent's atomic idle gate.
 *
 * `runMaintenance` refuses while a turn (or another maintenance job) is
 * running and latches prompts admitted meanwhile, so the surface can never be
 * read and replaced against a moving turn. The session must be live: the UI
 * button only appears on an open session, and a live append is validated by
 * the Session itself instead of being written blind.
 *
 * @param ctx - plugin context carrying `agents`, `sessions`, and a logger.
 * @param sessionId - session to roll back.
 * @param throughSeq - optional inclusive end anchor for a middle exchange.
 * @param turn - optional turn number whose exchange should be undone.
 * @returns `{ ok: true, ... }` or `{ ok: false, code, message? }`.
 */
export async function undoLatest(ctx, sessionId, throughSeq, turn) {
	const agent = ctx.agents?.get(sessionId);
	if (agent === undefined) {
		return { ok: false, code: 'not-live', message: 'Open this session in ZadLoop first, then undo.' };
	}
	const session = agent.session;
	if (session === undefined || typeof session.append !== 'function' || session.surface === undefined) {
		return { ok: false, code: 'unsupported', message: 'This ZadLoop build does not expose the required session APIs.' };
	}
	try {
		return await agent.runMaintenance(async () => {
			let anchor = throughSeq;
			let turns = null;
			if (turn !== undefined) {
				const scoped = session.snapshotEvents();
				turns = turnsCoveredBy(scoped);
				const resolved = lastSeqOfTurn(scoped, turns, turn);
				if (resolved < 0) return { ok: false, code: 'bad-anchor', message: 'That exchange is no longer in this session.' };
				anchor = resolved;
			}
			const plan = planUndo(session.snapshotEvents(), session.surface.nodes, anchor);
			if (!plan.ok) {
				const message = plan.code === 'nothing-to-undo'
					? 'No message from you to undo at that point.'
					: `Undo refused: ${plan.code}.`;
				return { ok: false, code: plan.code, message };
			}
			if (turn !== undefined && turns[plan.startSeq] !== turn) {
				// The anchor slid to an earlier exchange because this turn's own
				// messages already left the surface: it has been undone already.
				return { ok: false, code: 'bad-anchor', message: 'That exchange was already undone.' };
			}
			const marker = applyUndoMarker(session, plan);
			try {
				await ctx.sessions.flush(session);
			} catch (error) {
				ctx.logger?.warn?.('zadloop-undo: durability flush failed; the marker is in the log and flushes with the next event', error);
			}
			return {
				ok: true,
				removedMessages: plan.removedMessages,
				shadowedSeqs: [...plan.shadowedSeqs],
				markerSeq: marker.seq,
				preview: plan.preview,
				keptForAudit: true,
			};
		});
	} catch (error) {
		const message = String(error?.message ?? error);
		if (message.includes('already has active work')) {
			return { ok: false, code: 'busy', message: 'The agent is working. Stop the current turn, then undo.' };
		}
		return { ok: false, code: 'failed', message };
	}
}

/** Map every event seq to the turn open at that seq, or null between turns. */
function turnsCoveredBy(events) {
	const turns = new Array(events.length).fill(null);
	let open = null;
	for (const event of events) {
		if (event.type === 'turn/start' && isEventSeq(event.data?.turn)) open = event.data.turn;
		turns[event.seq] = open;
		if (event.type === 'turn/end') open = null;
	}
	return turns;
}

/** Resolve one turn number to its last event seq, or -1 when absent. */
function lastSeqOfTurn(events, turns, turn) {
	let last = -1;
	for (const event of events) if (turns[event.seq] === turn && event.seq > last) last = event.seq;
	return last;
}

/**
 * Read the durable undo markers of one live session so a freshly loaded page
 * can restore the hidden-transcript styling without replaying the log itself.
 * @param ctx - plugin context carrying `agents`.
 * @param sessionId - session to inspect.
 * @returns `{ ok, markers: [{ seq, shadowedSeqs, turns }] }`.
 */
export function undoState(ctx, sessionId) {
	const session = ctx.agents?.get(sessionId)?.session;
	if (session === undefined || typeof session.snapshotEvents !== 'function') {
		return { ok: false, markers: [] };
	}
	const events = session.snapshotEvents();
	const turns = turnsCoveredBy(events);
	const markers = [];
	for (const event of events) {
		if (event.type !== 'user/message' || event.surfaceOp === 'append') continue;
		if (event.data?.source?.kind !== MARKER_KIND) continue;
		const shadowedSeqs = [...(event.sourceEventSeqs ?? [])].filter(isEventSeq);
		markers.push({
			seq: event.seq,
			shadowedSeqs,
			turns: [...new Set(shadowedSeqs.map((seq) => turns[seq] ?? null).filter((turn) => turn !== null))],
		});
	}
	return { ok: true, markers };
}

/**
 * Mount the two `/api` routes the browser half calls. Per-session operations
 * are serialized (the shape the shipped message-feedback service uses) so two
 * rapid clicks cannot interleave two replacement plans.
 * @param ctx - Host plugin context.
 */
export function apply(ctx) {
	const tails = new Map();
	let open = true;
	ctx.effect(() => async () => {
		open = false;
		await Promise.all([...tails.values()]);
	}, 'zadloop-undo.drain');

	const enqueue = (sessionId, operation) => {
		if (!open) return Promise.reject(new Error('zadloop-undo: service is disposing'));
		const result = (tails.get(sessionId) ?? Promise.resolve()).then(operation);
		const tail = result.then(() => undefined, () => undefined);
		tails.set(sessionId, tail);
		return result.finally(() => {
			if (tails.get(sessionId) === tail) tails.delete(sessionId);
		});
	};

	ctx.effect(() => ctx.connection.fetch.register({
		path: UNDO_PATH,
		methods: ['POST'],
		requestBody: 'buffered',
		fetch: async (request) => {
			let body;
			try {
				body = await request.json();
			} catch {
				return Response.json({ ok: false, code: 'bad-request' }, { status: 400 });
			}
			const sessionId = body?.sessionId;
			const throughSeq = body?.throughSeq;
			const turn = body?.turn;
			if (typeof sessionId !== 'string' || sessionId.length === 0 || sessionId.length > 200
				|| (throughSeq !== undefined && !isEventSeq(throughSeq))
				|| (turn !== undefined && !isEventSeq(turn))) {
				return Response.json({ ok: false, code: 'bad-request' }, { status: 400 });
			}
			try {
				return Response.json(await enqueue(sessionId, () => undoLatest(ctx, sessionId, throughSeq, turn)));
			} catch (error) {
				ctx.logger?.warn?.('zadloop-undo: undo request failed', error);
				return Response.json({ ok: false, code: 'failed', message: String(error?.message ?? error) }, { status: 500 });
			}
		},
	}), 'zadloop-undo: /api undo route');

	ctx.effect(() => ctx.connection.fetch.register({
		path: STATE_PATH,
		methods: ['GET'],
		requestBody: 'buffered',
		fetch: async (request) => {
			const sessionId = new URL(request.url).searchParams.get('sessionId');
			if (typeof sessionId !== 'string' || sessionId.length === 0 || sessionId.length > 200) {
				return Response.json({ ok: false, markers: [] }, { status: 400 });
			}
			return Response.json(undoState(ctx, sessionId));
		},
	}), 'zadloop-undo: /api state route');
}
