# ZadLoop Theme Studio

A theme-only ZadLoop plugin. Open **Themes** beside the composer or press **Ctrl+Shift+T**.

It includes 72 curated, mode-exclusive themes: 51 dark themes and 21 light themes. The Light and Dark switches are separate collections, so a dark preset can never activate in light mode and a light preset can never activate in dark mode. Liquid Glass Day and Liquid Glass Night provide complete iOS-inspired recipes with translucent semantic surfaces, ambient tonal lighting, soft depth, rounded geometry, and mode-specific contrast.

Each preset is a complete semantic color system—not a background overlay. It recolors the app canvas, base and raised surfaces, sidebar, text hierarchy, links, buttons, native user-message bubbles, code blocks, inputs, selection states, borders, scrollbars, focus rings, and shadows. Optional tonal gradients are deliberately subtle, and preset textures and ambient glow default off.

Every choice is represented in an always-visible live inspector with a miniature interface, palette swatches, exact values, typography samples, density, geometry, depth, gradient, texture, glow, glass, and motion details. Choices are applied live through ZadLoop's theme service and saved locally.

The responsive studio has dedicated mouse, touch, and keyboard scroll regions, a sticky theme filter, stable scrollbars, and reduced-motion support. Its launcher follows ZadLoop's compact native action style. Theme Studio preserves the real conversation composer's native structure and spacing; themes only supply its semantic colors. The preview input exists only inside the settings window. This package has no context editor, prompts, skills, undo, commands, tools, session routes, or other non-theme behavior.
