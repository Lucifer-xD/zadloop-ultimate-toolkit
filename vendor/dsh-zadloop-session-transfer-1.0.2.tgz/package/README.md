# ZadLoop Session Transfer

Lossless transfer of complete ZadLoop sessions between computers.

The **Transfer** control in the conversation dock can:

- export the current session, all descendant subagent sessions, full event history, and referenced attachments;
- import that archive into another ZadLoop installation;
- preserve the session title, mode, model selection, access/permission events, messages, reasoning streams, tool calls/results, compaction history, plans, goals, and other session-scoped state;
- refresh ZadLoop's session list immediately after a successful import.

Imports preserve the original session IDs and therefore refuse an archive when one of those IDs already exists. No existing session is overwritten. Machine-wide credentials, provider secrets, and global application preferences are never exported.

Maximum compressed import size: 384 MiB. Maximum expanded archive size: 768 MiB.
