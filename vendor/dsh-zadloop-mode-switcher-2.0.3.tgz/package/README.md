# ZadLoop Mode Switcher

A compact native-style control beside the composer for changing an existing session between **Standard** and **Delegate** agent modes in place.

- It keeps the same session ID, transcript, workspace, and chat.
- It rebinds the live agent's internal preset composition and appends ZadLoop's native `agent-preset/selected` event to the existing session.
- It never opens a new session.
- If an agent turn is running, it refuses safely; finish or stop the turn and click again.
- The button always shows the current and target modes, such as `Delegate → Standard`.
- Existing history is never rewritten, deleted, or stopped.

This intentionally uses ZadLoop's internal `agentPresets.recompose` operation because the public selection API locks after the first turn.
